# Multiplayer Ludo Game Made with Node.js and Socket.io

<img src="public/assets/img/screenshots/loginpng.png">

<img src="public/assets/img/screenshots/lobbyScreenshot.png">
<img src="public/assets/img/screenshots/game.png">



